var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/mark-email-submitted/route.js")
R.c("server/chunks/[root-of-the-server]__5165e9aa._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_mark-email-submitted_route_actions_e8d38191.js")
R.m(42679)
module.exports=R.m(42679).exports
