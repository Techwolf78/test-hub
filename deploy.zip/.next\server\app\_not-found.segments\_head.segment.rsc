1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/c22315b1b79db542.js","/_next/static/chunks/d5ac21c25f446c29.js","/_next/static/chunks/6ec60a10d1823541.js"],"ViewportBoundary"]
4:I[97367,["/_next/static/chunks/c22315b1b79db542.js","/_next/static/chunks/d5ac21c25f446c29.js","/_next/static/chunks/6ec60a10d1823541.js"],"MetadataBoundary"]
5:"$Sreact.suspense"
0:{"buildId":"Wqw-17csga8axfSTivds8","rsc":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L2",null,{"children":"$@3"}],["$","div",null,{"hidden":true,"children":["$","$L4",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":"$@6"}]}]}],null]}],"loading":null,"isPartial":false}
3:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
6:[["$","title","0",{"children":"TESTNEX"}],["$","meta","1",{"name":"description","content":"Next.js + Firebase Auth Role Routing"}]]
