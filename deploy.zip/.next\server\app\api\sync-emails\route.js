var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sync-emails/route.js")
R.c("server/chunks/[root-of-the-server]__af8da153._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_sync-emails_route_actions_c7c43918.js")
R.m(83905)
module.exports=R.m(83905).exports
