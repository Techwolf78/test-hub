var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-submissions/route.js")
R.c("server/chunks/[root-of-the-server]__0f01484f._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_0700e68e._.js")
R.c("server/chunks/_next-internal_server_app_api_test-submissions_route_actions_78182d84.js")
R.m(70585)
module.exports=R.m(70585).exports
