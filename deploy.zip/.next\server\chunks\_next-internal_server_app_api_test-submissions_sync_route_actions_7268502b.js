module.exports=[12155,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_test-submissions_sync_route_actions_7268502b.js.map