module.exports=[77544,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_mark-email-submitted_route_actions_e8d38191.js.map