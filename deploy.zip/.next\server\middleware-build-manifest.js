globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/e6743a5d2d187d06.js",
    "static/chunks/759a23899af1f3b9.js",
    "static/chunks/eb903e07dc8f5f76.js",
    "static/chunks/822100010d52aeec.js",
    "static/chunks/turbopack-582d4e413ef7acfc.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];