module.exports=[85690,a=>{"use strict";var b=a.i(72131),c=a.i(50944);function d(){let a=(0,c.useRouter)();return(0,b.useEffect)(()=>{document.cookie.split(";").some(a=>a.trim().startsWith("auth="))?a.push("/user"):a.push("/login")},[a]),null}a.s(["default",()=>d])}];

//# sourceMappingURL=src_app_page_e6bfee3a.js.map