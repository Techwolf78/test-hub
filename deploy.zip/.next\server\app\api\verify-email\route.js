var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/verify-email/route.js")
R.c("server/chunks/[root-of-the-server]__a17786b5._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_verify-email_route_actions_5fdc5491.js")
R.m(6880)
module.exports=R.m(6880).exports
