var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/test-submissions/sync/route.js")
R.c("server/chunks/[root-of-the-server]__969208a2._.js")
R.c("server/chunks/[root-of-the-server]__1e03abeb._.js")
R.c("server/chunks/node_modules_5cf12a84._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_0700e68e._.js")
R.c("server/chunks/_next-internal_server_app_api_test-submissions_sync_route_actions_7268502b.js")
R.m(36852)
module.exports=R.m(36852).exports
