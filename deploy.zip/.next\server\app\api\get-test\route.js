var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/get-test/route.js")
R.c("server/chunks/[root-of-the-server]__8c835d33._.js")
R.c("server/chunks/[root-of-the-server]__969208a2._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_5cf12a84._.js")
R.c("server/chunks/_next-internal_server_app_api_get-test_route_actions_7254e578.js")
R.m(64303)
module.exports=R.m(64303).exports
