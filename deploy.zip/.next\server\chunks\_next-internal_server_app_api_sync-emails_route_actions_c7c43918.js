module.exports=[13338,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sync-emails_route_actions_c7c43918.js.map