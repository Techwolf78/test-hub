module.exports=[67612,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_get-test_route_actions_7254e578.js.map