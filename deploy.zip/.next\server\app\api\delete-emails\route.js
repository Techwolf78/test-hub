var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/delete-emails/route.js")
R.c("server/chunks/[root-of-the-server]__361348ca._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/_next-internal_server_app_api_delete-emails_route_actions_72bce512.js")
R.m(10367)
module.exports=R.m(10367).exports
