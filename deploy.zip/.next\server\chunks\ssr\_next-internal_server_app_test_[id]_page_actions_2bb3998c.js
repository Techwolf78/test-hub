module.exports=[31474,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_test_%5Bid%5D_page_actions_2bb3998c.js.map