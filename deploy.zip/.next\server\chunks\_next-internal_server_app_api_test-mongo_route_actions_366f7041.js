module.exports=[55896,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_test-mongo_route_actions_366f7041.js.map