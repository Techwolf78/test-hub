var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/test-mongo/route.js")
R.c("server/chunks/[root-of-the-server]__5d524a2c._.js")
R.c("server/chunks/[root-of-the-server]__8f5ebbc3._.js")
R.c("server/chunks/node_modules_next_0700e68e._.js")
R.c("server/chunks/_next-internal_server_app_api_test-mongo_route_actions_366f7041.js")
R.m(69321)
module.exports=R.m(69321).exports
