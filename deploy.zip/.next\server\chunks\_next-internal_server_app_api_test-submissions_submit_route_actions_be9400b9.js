module.exports=[25613,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_test-submissions_submit_route_actions_be9400b9.js.map